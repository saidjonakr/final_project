package com.example.final_project.service;

import com.example.final_project.dto.response.AdminResponse;

public interface AdminService {

	public AdminResponse getAdminData(String email);

}
