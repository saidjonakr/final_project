package com.example.final_project.enums;

public enum Status {
	ACTIVE, INACTIVE
}
