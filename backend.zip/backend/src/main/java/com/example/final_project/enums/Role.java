package com.example.final_project.enums;


public enum Role {
    PATIENT,
    DOCTOR,
    NURSE,
    STAFF,
    ADMIN // Example roles
}
